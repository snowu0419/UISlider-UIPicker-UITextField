//
//  ViewController.swift
//  HelloUISlider
//
//  Created by sMac on 2016/10/6.
//  Copyright © 2016年 sMac. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    
    @IBOutlet weak var redText: UITextField!
    @IBOutlet weak var greenText: UITextField!
    @IBOutlet weak var blueText: UITextField!
    @IBOutlet weak var redWord: UILabel!
    @IBOutlet weak var greenWord: UILabel!
    @IBOutlet weak var blueWord: UILabel!
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    @IBOutlet weak var pickerview: UIPickerView!
    
    
    var redValue:Int    = 255
    var greenValue:Int  = 255
    var blueValue:Int   = 255
    //陣列設定
    var redPickerView   = Array(0...255)
    var greenPickerView = Array(0...255)
    var bluePickerView  = Array(0...255)
    
    
    func  changeBackgroundColor() {
        view.backgroundColor = UIColor(red: CGFloat(redValue)/255.0, green: CGFloat(greenValue)/255.0, blue: CGFloat(blueValue)/255.0, alpha: 1)
    }
    
    func changeTextColor() {
        redWord.textColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        redText.textColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        
        greenWord.textColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        greenText.textColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        
        blueWord.textColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        blueText.textColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        changeBackgroundColor()
        
    }
    
    func colors(){
        changeTextColor()
        changeBackgroundColor()
    }
    
    func isHiddenGroup(){
        if(pickerview.isHidden)
        {
            pickerview.isHidden=false
            redSlider.isHidden = true
            greenSlider.isHidden = true
            blueSlider.isHidden = true
            
        } else{
            pickerview.isHidden=true
            redSlider.isHidden = false
            greenSlider.isHidden = false
            blueSlider.isHidden = false
    
        }
    }

    
    
    
    
    
    
    //PickerView
    //欄位 number of component
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 3
    }
    
    //各欄內要顯示的數量
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == 0{
            return redPickerView.count
        }else if component == 1{
            return greenPickerView.count
        }else{
            return bluePickerView.count
        }

    }
    
    //每一列要顯示什麼內容 title for row
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if component == 0{
            return "\(redPickerView[row])"
        }else if component == 1{
            return "\(greenPickerView[row])"
        }else{
            return "\(bluePickerView[row])"
        }
    }
    
    //picker view text color
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        
        var attributedString: NSAttributedString!
        let pickerViewColor = UIColor(red: CGFloat(255-redValue)/255.0, green: CGFloat(255-greenValue)/255.0, blue: CGFloat(255-blueValue)/255.0, alpha: 1)
        
        switch component {
        case 0:
            attributedString = NSAttributedString(string: "\(redPickerView[row])", attributes: [NSForegroundColorAttributeName : pickerViewColor])
        case 1:
            attributedString = NSAttributedString(string: "\(greenPickerView[row])", attributes: [NSForegroundColorAttributeName : pickerViewColor])
        case 2:
            attributedString = NSAttributedString(string: "\(bluePickerView[row])", attributes: [NSForegroundColorAttributeName : pickerViewColor])
        default:
            attributedString = nil
        }
        
        return attributedString
    }
    
    //點選後要執行的內容 did select row
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0{
            print("R Picker View : \(redPickerView[row])")
            redText.text = "\(redPickerView[row])"
            redValue = redPickerView[row]
            colors()
        }else if component == 1{
            print("G Picker View : \(greenPickerView[row])")
            greenText.text = "\(greenPickerView[row])"
            greenValue = greenPickerView[row]
            colors()
        }else{
            print("B Picker View : \(bluePickerView[row])")
            blueText.text = "\(bluePickerView[row])"
            blueValue = bluePickerView[row]
            colors()
        }
    }
    

    
    
    
    //Slider to TextField and change color
    @IBAction func redSliderChanged(_ sender: UISlider){
        redValue = Int(sender.value)
        redText.text = "\(redValue)"
        
        colors()
    }
    
    
    @IBAction func greenSliderChanged(_ sender: UISlider){
        greenValue = Int(sender.value)
        greenText.text = "\(greenValue)"
        
        colors()
    }
    
    @IBAction func blueSliderChanged(_ sender: UISlider){
        blueValue = Int(sender.value)
        blueText.text = "\(blueValue)"
      
        colors()
    }
    
    
    
    
    //Slider Hidden
    @IBAction func redTextTouch(_ sender: UITextField) {isHiddenGroup()}
    @IBAction func greenTextTouch(_ sender: UITextField) {isHiddenGroup()}
    @IBAction func blueTextTouch(_ sender: UITextField) {isHiddenGroup()}
    
    
    
    
    
    
    
    //TextField -> colors
    @IBAction func redTextChanged(_ sender: UITextField) {
        redValue = Int(redText.text!)!
        
        colors()
    }
    @IBAction func greenTextChanged(_ sender: UITextField) {
        greenValue = Int(greenText.text!)!
        colors()
    }
    @IBAction func blueTextChanged(_ sender: UITextField) {
        blueValue = Int(blueText.text!)!
        colors()
    }
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        let toolBar = UIToolbar()
//        toolBar.barStyle = UIBarStyle.default
//        toolBar.isTranslucent = true
//        toolBar.sizeToFit()
//        
//        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: "donePicker")
//        toolBar.setItems([doneButton], animated: false)
//        toolBar.isUserInteractionEnabled = true
        //redText.inputView = pickerview
        //redText.inputAccessoryView = toolBar
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

